from pathlib import Path
from math import pi

import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import streamlit.components.v1 as components

from bokeh.plotting import figure
from bokeh.models import ColumnDataSource, HoverTool
from bokeh.embed import file_html
from bokeh.resources import CDN

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix, classification_report)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier

# =====================================================
# 1. PAGE CONFIGURATION & EXECUTIVE STYLING
# =====================================================

st.set_page_config(
    page_title="Customer Churn Intelligence Dash Board",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

sns.set_theme(style="whitegrid")

st.markdown("""
<style>
/* Main Background & Typography */
.stApp {
    background-color: #f8fafc;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}

/* Sidebar Background & Card Look */
[data-testid="stSidebar"] {
    background-color: #f1f5f9;
    border-right: 1px solid #e2e8f0;
}
[data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {
    color: #0f172a;
    font-weight: 700;
}

/* Metric Cards */
[data-testid="stMetric"] {
    background: #ffffff;
    padding: 18px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}
[data-testid="stMetricLabel"] {
    font-size: 0.85rem !important;
    font-weight: 600 !important;
    color: #475569 !important;
}
[data-testid="stMetricValue"] {
    font-size: 1.55rem !important;
    font-weight: 700 !important;
    color: #0f172a !important;
}

/* Headers */
h1 {
    color: #0f172a;
    font-weight: 800;
    letter-spacing: -0.02em;
}
h2 {
    color: #1e293b;
    font-weight: 700;
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 6px;
    margin-top: 1.5rem;
}
h3 {
    color: #334155;
    font-weight: 600;
}

/* Chart Container Cards */
.chart-card {
    background: #ffffff;
    padding: 22px;
    border-radius: 14px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
    margin-bottom: 24px;
}

/* Filter Control Bar / Container Inside Charts */
.chart-filter-container {
    background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 12px 16px;
    margin-bottom: 16px;
}
.chart-filter-title {
    font-size: 0.82rem;
    font-weight: 700;
    color: #334155;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

/* Multiselect Badge / Pill Modern Gradient Styling */
[data-baseweb="tag"] {
    background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%) !important;
    color: #1e40af !important;
    border: 1px solid #bfdbfe !important;
    border-radius: 6px !important;
    font-weight: 600 !important;
    padding: 2px 8px !important;
}
[data-baseweb="tag"]:hover {
    background: #bfdbfe !important;
}

/* Selectbox Dropdown Rounded Input Styling with Glow */
[data-baseweb="select"] > div {
    border-radius: 10px !important;
    border: 1.5px solid #cbd5e1 !important;
    background-color: #ffffff !important;
    transition: all 0.2s ease-in-out !important;
}
[data-baseweb="select"] > div:hover, [data-baseweb="select"] > div:focus-within {
    border-color: #3b82f6 !important;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.18) !important;
}

/* Radio Button Options Formatting */
[data-testid="stRadio"] label {
    font-weight: 500 !important;
    color: #1e293b !important;
}
</style>
""", unsafe_allow_html=True)

st.title("📊 Customer Churn Intelligence Dash Board")
st.caption(
    "Enterprise Analytics | Predictive Churn Modeling | "
    "Multi-Library Data Visualizations (Matplotlib, Pyplot, Seaborn, Bokeh)"
)

# =====================================================
# 2. LOAD DATASET
# =====================================================

@st.cache_data
def load_data():
    path = Path(__file__).parent / "Data.csv"
    raw = pd.read_csv(path)
    df = raw.copy()

    if "customerID" in df.columns:
        df = df.drop(columns=["customerID"])

    df["TotalCharges"] = pd.to_numeric(
        df["TotalCharges"], errors="coerce"
    )
    df = df.dropna(subset=["TotalCharges", "Churn"])
    return raw, df

raw_df, df = load_data()

# =====================================================
# 2A. MACHINE LEARNING MODEL (RANDOM FOREST)
# =====================================================

@st.cache_resource
def train_churn_model(data):
    """Train and cache a Random Forest churn classifier."""
    model_data = data.copy()
    y = model_data["Churn"].map({"No": 0, "Yes": 1})
    X = model_data.drop(columns=["Churn"], errors="ignore")
    X = X.drop(columns=["customerID"], errors="ignore")

    numeric_features = X.select_dtypes(include=["number"]).columns.tolist()
    categorical_features = X.select_dtypes(exclude=["number"]).columns.tolist()

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore"))
    ])

    transformers = []
    if numeric_features:
        transformers.append(("numeric", numeric_pipeline, numeric_features))
    if categorical_features:
        transformers.append(("categorical", categorical_pipeline, categorical_features))

    preprocessing = ColumnTransformer(transformers=transformers)
    classifier = RandomForestClassifier(
        n_estimators=250,
        random_state=42,
        class_weight="balanced",
        min_samples_leaf=2,
        n_jobs=-1
    )
    pipeline = Pipeline([
        ("preprocessing", preprocessing),
        ("classifier", classifier)
    ])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)
    metrics = {
        "accuracy": accuracy_score(y_test, predictions),
        "precision": precision_score(y_test, predictions, zero_division=0),
        "recall": recall_score(y_test, predictions, zero_division=0),
        "f1": f1_score(y_test, predictions, zero_division=0),
        "confusion": confusion_matrix(y_test, predictions, labels=[0, 1]),
        "report": classification_report(
            y_test, predictions, labels=[0, 1],
            target_names=["Retained", "Churned"],
            output_dict=True, zero_division=0
        ),
        "test_actual": y_test,
        "test_predicted": predictions
    }
    return pipeline, metrics

try:
    churn_model, model_metrics = train_churn_model(df)
    model_ready = True
except Exception as model_error:
    churn_model, model_metrics = None, None
    model_ready = False
    st.error(f"Machine learning model could not be trained: {model_error}")

# =====================================================
# 3. SIDEBAR FILTERS & CONTROLS
# =====================================================

st.sidebar.title("⚙️ Control Panel")
st.sidebar.caption("Configure chart engines, graph views, and cohort filters")

# Initialize Session State
if "selected_viz_library" not in st.session_state:
    st.session_state.selected_viz_library = "Matplotlib"

if "active_graph_selection" not in st.session_state:
    st.session_state.active_graph_selection = "All 6 Graphs"

if "custom_graphs_list" not in st.session_state:
    st.session_state.custom_graphs_list = [
        "Bar Graph", "Histogram", "Scatter Plot", "Line Chart", "Pie Chart", "Box Plot"
    ]

# 1. Chart Engine Selection in Sidebar
st.sidebar.subheader("🎨 Chart Engine")
selected_lib_sidebar = st.sidebar.radio(
    "Active Graph Library",
    options=["Matplotlib", "Pyplot", "Seaborn", "Bokeh"],
    index=["Matplotlib", "Pyplot", "Seaborn", "Bokeh"].index(st.session_state.selected_viz_library),
    key="sidebar_lib_radio",
    help="Switches the charting engine for all visualizations simultaneously."
)
if selected_lib_sidebar != st.session_state.selected_viz_library:
    st.session_state.selected_viz_library = selected_lib_sidebar
    st.rerun()

# 2. Graph Selection in Sidebar (Matching the Library selector style!)
st.sidebar.divider()
st.sidebar.subheader("📊 Graph Selection")
graph_options = [
    "All 6 Graphs",
    "Bar Graph",
    "Histogram",
    "Scatter Plot",
    "Line Chart",
    "Pie Chart",
    "Box Plot",
    "Custom Multi-Select"
]

selected_graph_sidebar = st.sidebar.radio(
    "Active Graph to Display",
    options=graph_options,
    index=graph_options.index(st.session_state.active_graph_selection) if st.session_state.active_graph_selection in graph_options else 0,
    key="sidebar_graph_radio",
    help="Select 'All 6 Graphs' to display everything together, or pick an individual graph."
)
if selected_graph_sidebar != st.session_state.active_graph_selection:
    st.session_state.active_graph_selection = selected_graph_sidebar
    if "main_graph_radio" in st.session_state:
        st.session_state.main_graph_radio = selected_graph_sidebar
    st.rerun()

if st.session_state.active_graph_selection == "Custom Multi-Select":
    st.session_state.custom_graphs_list = st.sidebar.multiselect(
        "Choose Graphs to Display",
        options=["Bar Graph", "Histogram", "Scatter Plot", "Line Chart", "Pie Chart", "Box Plot"],
        default=st.session_state.custom_graphs_list,
        key="sidebar_custom_graphs"
    )

# 3. Enhanced Cohort Filters in Sidebar with Icons and Clean Styling
st.sidebar.divider()
st.sidebar.subheader("🔍 Cohort Filters")

filter_meta = {
    "gender": {"label": "👤 Gender", "help": "Filter cohort by customer gender"},
    "Contract": {"label": "📜 Contract Type", "help": "Filter by Month-to-month, One year, Two year"},
    "InternetService": {"label": "🌐 Internet Service", "help": "Filter by DSL, Fiber optic, or None"},
    "PaymentMethod": {"label": "💳 Payment Method", "help": "Filter by electronic check, credit card, etc."}
}

filtered_df = df.copy()

filter_columns = [
    "gender",
    "Contract",
    "InternetService",
    "PaymentMethod"
]

for column in filter_columns:
    if column in filtered_df.columns:
        meta = filter_meta.get(column, {"label": column, "help": f"Filter by {column}"})
        options = sorted(filtered_df[column].dropna().unique().tolist())
        selected = st.sidebar.multiselect(
            meta["label"],
            options,
            default=options,
            help=meta["help"],
            key=f"filter_{column}"
        )
        filtered_df = filtered_df[filtered_df[column].isin(selected)]

st.sidebar.divider()
st.sidebar.metric(
    "Filtered Customers",
    f"{len(filtered_df):,}"
)

if st.sidebar.button("🔄 Reset Dash Board", use_container_width=True):
    st.session_state.selected_viz_library = "Matplotlib"
    st.session_state.active_graph_selection = "All 6 Graphs"
    st.session_state.custom_graphs_list = [
        "Bar Graph", "Histogram", "Scatter Plot", "Line Chart", "Pie Chart", "Box Plot"
    ]
    st.rerun()

# Helper for Bokeh rendering
def render_bokeh_chart(p, height=440):
    """Render a Bokeh figure cleanly in Streamlit with standard CDN."""
    p.toolbar.logo = None
    html = file_html(p, CDN, "Bokeh Chart")
    components.html(html, height=height, scrolling=False)

# =====================================================
# 4. CUSTOMER OVERVIEW / KPI
# =====================================================

st.header("📌 Business Performance Overview")

total = len(filtered_df)
churned_df = filtered_df[filtered_df["Churn"] == "Yes"]
retained_df = filtered_df[filtered_df["Churn"] == "No"]

churned = len(churned_df)
retained = len(retained_df)

churn_rate = (churned / total * 100 if total else 0)
retention_rate = (retained / total * 100 if total else 0)
monthly_revenue = (filtered_df["MonthlyCharges"].sum() if total else 0)
historical_monthly_charges_lost = (churned_df["MonthlyCharges"].sum() if churned else 0)

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Customers", f"{total:,}")
k2.metric("Churned Customers", f"{churned:,}")
k3.metric("Retained Customers", f"{retained:,}")
k4.metric("Churn Rate", f"{churn_rate:.2f}%")

k5, k6, k7 = st.columns(3)
k5.metric("Retention Rate", f"{retention_rate:.2f}%")
k6.metric("Monthly Charges (Cohort)", f"${monthly_revenue:,.2f}")
k7.metric("Monthly Revenue Lost (Churned)", f"${historical_monthly_charges_lost:,.2f}")

st.caption(
    "Revenue figures are computed from the active filtered records. "
    "Monthly Revenue Lost represents the recurring monthly revenue associated with churned accounts."
)

# =====================================================
# 5. BUSINESS INTELLIGENCE
# =====================================================

st.divider()
st.header("💼 Business Intelligence")

if total > 0:
    b1, b2 = st.columns(2)

    with b1:
        st.subheader("Customer Loyalty Analysis")
        avg_churn_tenure = (churned_df["tenure"].mean() if churned else 0)
        avg_retained_tenure = (retained_df["tenure"].mean() if retained else 0)

        st.metric("Average Churned Customer Tenure", f"{avg_churn_tenure:.1f} months")
        st.metric("Average Retained Customer Tenure", f"{avg_retained_tenure:.1f} months")

        if avg_churn_tenure < avg_retained_tenure:
            st.info("Churned customers have significantly lower average tenure. Early customer onboarding and the first 90 days are critical retention windows.")
        else:
            st.info("Churned customers do not show lower tenure in the currently filtered cohort.")

    with b2:
        st.subheader("Customer Revenue Analysis")
        avg_churn_charge = (churned_df["MonthlyCharges"].mean() if churned else 0)
        avg_retained_charge = (retained_df["MonthlyCharges"].mean() if retained else 0)

        st.metric("Average Churned Customer Charges", f"${avg_churn_charge:.2f}")
        st.metric("Average Retained Customer Charges", f"${avg_retained_charge:.2f}")

        if avg_churn_charge > avg_retained_charge:
            st.info("Churned customers carry higher monthly charges. High pricing without perceived proportional value is a key churn driver.")
        else:
            st.info("Churned customers have comparable or lower monthly charges.")

# =====================================================
# 6. CUSTOMER SEGMENTATION
# =====================================================

st.divider()
st.header("👥 Customer Segmentation")

if total > 0:
    segments = filtered_df.copy()
    segments["Customer Segment"] = pd.cut(
        segments["tenure"],
        bins=[-1, 12, 48, 1000],
        labels=["New (0-12 months)", "Regular (13-48 months)", "Long-term (49+ months)"]
    )

    segment_data = (
        segments.groupby("Customer Segment", observed=False)
        .agg(
            Customers=("Churn", "size"),
            Churned=("Churn", lambda x: (x == "Yes").sum())
        )
        .reset_index()
    )

    segment_data["Churn Rate (%)"] = (
        segment_data["Churned"] /
        segment_data["Customers"].replace(0, pd.NA) * 100
    ).fillna(0)

    st.dataframe(segment_data, use_container_width=True, hide_index=True)

    fig, ax = plt.subplots(figsize=(9, 4.5), dpi=120)
    bars = ax.bar(
        segment_data["Customer Segment"].astype(str),
        segment_data["Churn Rate (%)"],
        color=["#ef4444", "#f59e0b", "#10b981"],
        width=0.5,
        edgecolor="white",
        linewidth=1.5
    )
    ax.set_title("Observed Churn Rate by Customer Segment", fontsize=13, fontweight="bold", pad=12)
    ax.set_ylabel("Churn Rate (%)", fontsize=11, fontweight="semibold")
    ax.set_xlabel("Customer Segment", fontsize=11, fontweight="semibold")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    for bar in bars:
        h = bar.get_height()
        ax.annotate(f"{h:.1f}%", xy=(bar.get_x() + bar.get_width() / 2, h),
                    xytext=(0, 4), textcoords="offset points", ha="center", va="bottom",
                    fontweight="bold", fontsize=10)
    plt.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

# =====================================================
# 7. CHURN REASON ANALYSIS
# =====================================================

st.divider()
st.header("🔍 Customer Behaviour Analysis")

category_options = [
    "Contract", "PaymentMethod", "InternetService",
    "gender", "OnlineSecurity", "TechSupport"
]
available_categories = [c for c in category_options if c in filtered_df.columns]

if available_categories and total > 0:
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">🔍 Category Filter Dimension</div>
    """, unsafe_allow_html=True)
    selected_category = st.selectbox(
        "Select customer category to analyse",
        available_categories,
        key="behaviour_category"
    )
    st.markdown("</div>", unsafe_allow_html=True)

    behaviour = (
        filtered_df.groupby(selected_category, observed=False)
        .agg(
            Total=("Churn", "size"),
            Churned=("Churn", lambda x: (x == "Yes").sum())
        )
        .reset_index()
    )
    behaviour["Churn Rate (%)"] = (
        behaviour["Churned"] / behaviour["Total"] * 100
    ).fillna(0)

    st.dataframe(behaviour, use_container_width=True, hide_index=True)

    fig, ax = plt.subplots(figsize=(10, 4.8), dpi=120)
    colors = plt.cm.Blues(np.linspace(0.4, 0.85, len(behaviour)))
    bars = ax.bar(
        behaviour[selected_category].astype(str),
        behaviour["Churn Rate (%)"],
        color=colors,
        width=0.55,
        edgecolor="white",
        linewidth=1.2
    )
    ax.set_title(f"Churn Rate by {selected_category}", fontsize=13, fontweight="bold", pad=12)
    ax.set_ylabel("Churn Rate (%)", fontsize=11, fontweight="semibold")
    ax.set_xlabel(selected_category, fontsize=11, fontweight="semibold")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    plt.xticks(rotation=20, ha="right")
    for bar in bars:
        h = bar.get_height()
        ax.annotate(f"{h:.1f}%", xy=(bar.get_x() + bar.get_width() / 2, h),
                    xytext=(0, 4), textcoords="offset points", ha="center", va="bottom",
                    fontweight="bold", fontsize=10)
    plt.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

# =====================================================
# 8. CHURN PREDICTION AND RISK CLASSIFICATION
# =====================================================

st.divider()
st.header("🤖 Churn Prediction & Risk Classification")
st.caption("Random Forest predictions estimate churn likelihood for proactive customer retention.")

if model_ready and not filtered_df.empty:
    prediction_input = filtered_df.drop(columns=["Churn"], errors="ignore").copy()
    churn_probabilities = churn_model.predict_proba(prediction_input)[:, 1]
    risk_results = filtered_df.copy()
    risk_results["Predicted Churn Probability (%)"] = churn_probabilities * 100
    risk_results["Predicted Churn"] = churn_model.predict(prediction_input)
    risk_results["Predicted Churn"] = risk_results["Predicted Churn"].map({0: "No", 1: "Yes"})
    risk_results["Risk Level"] = pd.cut(
        risk_results["Predicted Churn Probability (%)"],
        bins=[-0.001, 30, 60, 100.001],
        labels=["Low", "Medium", "High"]
    ).astype(str)

    risk_counts = risk_results["Risk Level"].value_counts().reindex(
        ["High", "Medium", "Low"], fill_value=0
    )
    r1, r2, r3 = st.columns(3)
    r1.metric("High-Risk Accounts (>60%)", f"{risk_counts['High']:,}")
    r2.metric("Medium-Risk Accounts (30-60%)", f"{risk_counts['Medium']:,}")
    r3.metric("Low-Risk Accounts (<30%)", f"{risk_counts['Low']:,}")

    st.subheader("Customer-Level Churn Risk Roster")
    display_cols = [c for c in ["tenure", "Contract", "MonthlyCharges", "Churn",
                                "Predicted Churn", "Predicted Churn Probability (%)", "Risk Level"]
                    if c in risk_results.columns]
    st.dataframe(
        risk_results[display_cols].sort_values(
            "Predicted Churn Probability (%)", ascending=False
        ).style.format({"Predicted Churn Probability (%)": "{:.1f}%"}),
        use_container_width=True, hide_index=True
    )
    st.download_button(
        "⬇️ Download Churn Risk Report (CSV)",
        risk_results.to_csv(index=False).encode("utf-8"),
        file_name="customer_churn_risk_report.csv",
        mime="text/csv"
    )
else:
    st.info("Adjust the filters or verify model training to inspect churn predictions.")

# =====================================================
# 9. REVENUE LOSS ANALYSIS
# =====================================================

st.divider()
st.header("💰 Revenue Loss Analysis")
if not filtered_df.empty:
    lost_monthly = filtered_df.loc[filtered_df["Churn"] == "Yes", "MonthlyCharges"].sum()
    lost_annualized = lost_monthly * 12
    avg_lost = filtered_df.loc[filtered_df["Churn"] == "Yes", "MonthlyCharges"].mean()
    rev1, rev2, rev3 = st.columns(3)
    rev1.metric("Monthly Revenue at Churn", f"${lost_monthly:,.2f}")
    rev2.metric("Annualized Revenue Equivalent", f"${lost_annualized:,.2f}")
    rev3.metric("Average Monthly Charge / Churned Customer", f"${avg_lost:,.2f}" if pd.notna(avg_lost) else "$0.00")

    if "Contract" in filtered_df.columns:
        revenue_by_contract = (
            filtered_df[filtered_df["Churn"] == "Yes"]
            .groupby("Contract", observed=False)["MonthlyCharges"]
            .sum().sort_values(ascending=False).reset_index()
        )
        if not revenue_by_contract.empty:
            st.subheader("Monthly Charges Associated with Churn by Contract")
            st.dataframe(revenue_by_contract, use_container_width=True, hide_index=True)

# =====================================================
# 10. MACHINE LEARNING MODEL PERFORMANCE
# =====================================================

st.divider()
st.header("🧪 ML Model Performance")
if model_ready:
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Accuracy", f"{model_metrics['accuracy'] * 100:.2f}%")
    m2.metric("Precision", f"{model_metrics['precision'] * 100:.2f}%")
    m3.metric("Recall", f"{model_metrics['recall'] * 100:.2f}%")
    m4.metric("F1-Score", f"{model_metrics['f1'] * 100:.2f}%")

    cm = model_metrics["confusion"]
    fig, ax = plt.subplots(figsize=(6, 3.8), dpi=120)
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Pred Retained", "Pred Churned"],
        yticklabels=["Act Retained", "Act Churned"],
        ax=ax, cbar=False
    )
    ax.set_title("Confusion Matrix — Test Split", fontsize=12, fontweight="bold")
    ax.set_xlabel("Predicted Label", fontweight="semibold")
    ax.set_ylabel("Actual Label", fontweight="semibold")
    plt.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

    with st.expander("Detailed Classification Report"):
        report_df = pd.DataFrame(model_metrics["report"]).transpose()
        st.dataframe(report_df.round(3), use_container_width=True)

# =====================================================
# 11. STATISTICAL ANALYSIS
# =====================================================

st.divider()
st.header("📈 Statistical Analysis")

num_cols = [
    c for c in filtered_df.select_dtypes(include="number").columns
    if c != "SeniorCitizen"
]

if num_cols and total > 0:
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">📈 Statistical Attribute Selection</div>
    """, unsafe_allow_html=True)
    selected_stat = st.selectbox("Choose numerical attribute", num_cols, key="stat_column")
    st.markdown("</div>", unsafe_allow_html=True)

    values = filtered_df[selected_stat].dropna()
    if not values.empty:
        a, b, c = st.columns(3)
        d, e, f = st.columns(3)
        a.metric("Mean", f"{values.mean():.2f}")
        b.metric("Median", f"{values.median():.2f}")
        mode_val = values.mode()
        c.metric("Mode", f"{mode_val.iloc[0]:.2f}" if not mode_val.empty else "N/A")
        d.metric("Std Deviation", f"{values.std():.2f}")
        e.metric("Minimum", f"{values.min():.2f}")
        f.metric("Maximum", f"{values.max():.2f}")

# =====================================================
# 12. ADVANCED DATA VISUALIZATION: MULTI-ENGINE HUB (6 GRAPHS)
# =====================================================

st.divider()
st.header("📊 Advanced Data Visualization: Multi-Library Engine")
st.markdown("""
Select your preferred graphing library and visualization view below. **Clicking any library applies that engine across all selected visualizations** with tailored executive styling.
""")

# Library Selector Buttons
active_lib = st.session_state.selected_viz_library

col_btn1, col_btn2, col_btn3, col_btn4 = st.columns(4)

with col_btn1:
    if st.button("🎨 Matplotlib", key="lib_matplot_btn",
                 type="primary" if active_lib == "Matplotlib" else "secondary",
                 use_container_width=True):
        st.session_state.selected_viz_library = "Matplotlib"
        st.session_state.sidebar_lib_radio = "Matplotlib"
        st.rerun()

with col_btn2:
    if st.button("📈 Pyplot", key="lib_pyplot_btn",
                 type="primary" if active_lib == "Pyplot" else "secondary",
                 use_container_width=True):
        st.session_state.selected_viz_library = "Pyplot"
        st.session_state.sidebar_lib_radio = "Pyplot"
        st.rerun()

with col_btn3:
    if st.button("🌊 Seaborn", key="lib_seaborn_btn",
                 type="primary" if active_lib == "Seaborn" else "secondary",
                 use_container_width=True):
        st.session_state.selected_viz_library = "Seaborn"
        st.session_state.sidebar_lib_radio = "Seaborn"
        st.rerun()

with col_btn4:
    if st.button("✨ Bokeh (Interactive)", key="lib_bokeh_btn",
                 type="primary" if active_lib == "Bokeh" else "secondary",
                 use_container_width=True):
        st.session_state.selected_viz_library = "Bokeh"
        st.session_state.sidebar_lib_radio = "Bokeh"
        st.rerun()

# Engine Description Banner
engine_descriptions = {
    "Matplotlib": "🎨 **Active Engine: Matplotlib (OOP)** — Modern corporate styling, high DPI (130), subtle horizontal gridlines, direct value callouts, and clean spine removal.",
    "Pyplot": "📈 **Active Engine: Pyplot (Scientific / MATLAB)** — Publication-grade high-contrast layout, dual reference grid, boxed annotation badges, and formal axes markings.",
    "Seaborn": "🌊 **Active Engine: Seaborn** — Statistical aesthetics, smooth Kernel Density Estimation (KDE) curves, muted harmonious palettes, and strip distribution overlays.",
    "Bokeh": "✨ **Active Engine: Bokeh (Interactive HTML5 Canvas)** — Rich interactive features: hover tooltips with formatted metrics, pan, box zoom, wheel zoom, reset, and live click-to-hide legends."
}
st.info(engine_descriptions.get(active_lib, ""))

# Graph Selection Radio (Just like the Library selection radio!)
st.subheader("📊 Graph Selection")
selected_graph_main = st.radio(
    "Active Graph to Display",
    options=graph_options,
    index=graph_options.index(st.session_state.active_graph_selection) if st.session_state.active_graph_selection in graph_options else 0,
    horizontal=True,
    key="main_graph_radio",
    help="Select 'All 6 Graphs' to display everything, or pick an individual graph."
)
if selected_graph_main != st.session_state.active_graph_selection:
    st.session_state.active_graph_selection = selected_graph_main
    st.session_state.sidebar_graph_radio = selected_graph_main
    st.rerun()

# Determine which graphs to display
if st.session_state.active_graph_selection == "All 6 Graphs":
    graphs_to_display = ["Bar Graph", "Histogram", "Scatter Plot", "Line Chart", "Pie Chart", "Box Plot"]
elif st.session_state.active_graph_selection == "Custom Multi-Select":
    graphs_to_display = st.session_state.custom_graphs_list
else:
    graphs_to_display = [st.session_state.active_graph_selection]

st.caption(f"Currently displaying: **{st.session_state.active_graph_selection}** using **{active_lib}** engine")

if filtered_df.empty:
    st.warning("No customer records match the selected filters. Please adjust the sidebar filters.")
elif not graphs_to_display:
    st.info("No graphs selected. Select 'All 6 Graphs' or choose a specific graph to display.")

# =========================================================================
# GRAPH 1: CUSTOMER CHURN BAR GRAPH (ALL 4 LIBRARIES)
# =========================================================================

if "Bar Graph" in graphs_to_display and not filtered_df.empty:
    st.markdown('<div class="chart-card">', unsafe_allow_html=True)
    st.subheader(f"1. Customer Churn Bar Graph — [{active_lib}]")
    st.caption("Volume and proportion comparison between retained and churned customers.")

    counts = filtered_df["Churn"].value_counts().reindex(["No", "Yes"], fill_value=0)
    ret_cnt = int(counts.get("No", 0))
    chn_cnt = int(counts.get("Yes", 0))
    tot_cnt = ret_cnt + chn_cnt
    ret_pct = (ret_cnt / tot_cnt * 100) if tot_cnt else 0
    chn_pct = (chn_cnt / tot_cnt * 100) if tot_cnt else 0

    if active_lib == "Matplotlib":
        fig, ax = plt.subplots(figsize=(9, 4.6), dpi=130)
        bars = ax.bar(
            ["Retained (No)", "Churned (Yes)"],
            [ret_cnt, chn_cnt],
            color=["#2563EB", "#DC2626"],
            width=0.48,
            edgecolor="white",
            linewidth=1.8,
            zorder=3
        )
        ax.set_title("Customer Volume: Retained vs Churned", fontsize=13, fontweight="bold", pad=12)
        ax.set_ylabel("Number of Customers", fontsize=11, fontweight="semibold")
        ax.set_xlabel("Churn Status", fontsize=11, fontweight="semibold")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color("#CBD5E1")
        ax.spines["bottom"].set_color("#CBD5E1")
        ax.grid(axis="y", linestyle="--", alpha=0.35, color="#94A3B8", zorder=0)
        max_c = max(ret_cnt, chn_cnt)
        ax.set_ylim(0, max_c * 1.18 if max_c else 10)
        for bar, cnt, pct in zip(bars, [ret_cnt, chn_cnt], [ret_pct, chn_pct]):
            h = bar.get_height()
            ax.annotate(f"{cnt:,}\n({pct:.1f}%)",
                        xy=(bar.get_x() + bar.get_width() / 2, h),
                        xytext=(0, 6), textcoords="offset points",
                        ha="center", va="bottom", fontsize=10.5, fontweight="bold", color="#1E293B")
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Pyplot":
        plt.figure(figsize=(9, 4.6), dpi=130)
        bars = plt.bar(
            ["Retained (No)", "Churned (Yes)"],
            [ret_cnt, chn_cnt],
            color=["#0F172A", "#EA580C"],
            edgecolor="#334155",
            linewidth=1.5,
            width=0.48
        )
        plt.title("CUSTOMER CHURN VOLUME (PYPLOT SCIENTIFIC SPEC)", fontsize=12.5, fontweight="bold", pad=12)
        plt.ylabel("Customer Count (Frequency)", fontweight="bold")
        plt.xlabel("Classification Cohort", fontweight="bold")
        plt.grid(True, linestyle=":", alpha=0.45, color="#64748B")
        max_c = max(ret_cnt, chn_cnt)
        plt.ylim(0, max_c * 1.2 if max_c else 10)
        for bar, cnt, pct in zip(bars, [ret_cnt, chn_cnt], [ret_pct, chn_pct]):
            h = bar.get_height()
            plt.annotate(f"{cnt:,} ({pct:.1f}%)",
                         xy=(bar.get_x() + bar.get_width() / 2, h),
                         xytext=(0, 6), textcoords="offset points",
                         ha="center", va="bottom", fontsize=10, fontweight="bold",
                         bbox=dict(boxstyle="round,pad=0.3", facecolor="#F8FAFC", edgecolor="#94A3B8", alpha=0.9))
        plt.tight_layout()
        st.pyplot(plt.gcf())
        plt.close()

    elif active_lib == "Seaborn":
        fig, ax = plt.subplots(figsize=(9, 4.6), dpi=130)
        bar_df = pd.DataFrame({
            "Status": ["Retained (No)", "Churned (Yes)"],
            "Count": [ret_cnt, chn_cnt]
        })
        sns.barplot(
            data=bar_df, x="Status", y="Count", hue="Status",
            palette=["#16A34A", "#E11D48"], ax=ax, legend=False, width=0.48
        )
        ax.set_title("Customer Churn Distribution (Seaborn Theme)", fontsize=13, fontweight="bold", pad=12)
        ax.set_ylabel("Customer Count", fontsize=11, fontweight="semibold")
        ax.set_xlabel("Churn Status", fontsize=11, fontweight="semibold")
        sns.despine(top=True, right=True, left=True)
        max_c = max(ret_cnt, chn_cnt)
        ax.set_ylim(0, max_c * 1.18 if max_c else 10)
        for container, pct in zip(ax.containers, [ret_pct, chn_pct]):
            for bar, p_val in zip(container, [ret_pct, chn_pct]):
                h = bar.get_height()
                ax.annotate(f"{int(h):,} ({p_val:.1f}%)",
                            xy=(bar.get_x() + bar.get_width() / 2, h),
                            xytext=(0, 6), textcoords="offset points",
                            ha="center", va="bottom", fontsize=10.5, fontweight="semibold")
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Bokeh":
        p = figure(
            x_range=["Retained (No)", "Churned (Yes)"],
            title="Customer Churn Volume (Bokeh Interactive)",
            height=430,
            sizing_mode="stretch_width",
            tools="pan,wheel_zoom,box_zoom,reset,save"
        )
        b_df = pd.DataFrame({
            "status": ["Retained (No)", "Churned (Yes)"],
            "count": [ret_cnt, chn_cnt],
            "pct": [f"{ret_pct:.1f}%", f"{chn_pct:.1f}%"],
            "color": ["#2563EB", "#DC2626"]
        })
        source = ColumnDataSource(b_df)
        renderer = p.vbar(x="status", top="count", width=0.48, color="color", source=source)
        hover = HoverTool(
            renderers=[renderer],
            tooltips="""
            <div style="padding: 6px; font-family: sans-serif;">
                <b style="color: @color; font-size: 13px;">@status</b><br>
                <span>Customers: <b>@count{0,0}</b></span><br>
                <span>Share: <b>@pct</b></span>
            </div>
            """
        )
        p.add_tools(hover)
        p.yaxis.axis_label = "Number of Customers"
        p.xaxis.axis_label = "Churn Status"
        p.y_range.start = 0
        p.y_range.end = (max(ret_cnt, chn_cnt) * 1.2) if max(ret_cnt, chn_cnt) else 10
        render_bokeh_chart(p, height=440)

    st.markdown('</div>', unsafe_allow_html=True)

# =========================================================================
# GRAPH 2: CUSTOMER DATA HISTOGRAM (ALL 4 LIBRARIES)
# =========================================================================

if "Histogram" in graphs_to_display and not filtered_df.empty and num_cols:
    st.markdown('<div class="chart-card">', unsafe_allow_html=True)
    st.subheader(f"2. Customer Data Histogram — [{active_lib}]")
    st.caption("Distribution analysis of key numerical attributes split by churn status.")

    # Styled Chart Filter Control Bar
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">⚙️ Chart Dimension Control</div>
    """, unsafe_allow_html=True)
    hist_col = st.selectbox("Choose histogram attribute to plot", num_cols, key="hist_column_hub")
    st.markdown("</div>", unsafe_allow_html=True)

    ret_series = filtered_df[filtered_df["Churn"] == "No"][hist_col].dropna()
    chn_series = filtered_df[filtered_df["Churn"] == "Yes"][hist_col].dropna()

    if active_lib == "Matplotlib":
        fig, ax = plt.subplots(figsize=(9, 4.6), dpi=130)
        ax.hist(ret_series, bins=26, alpha=0.65, color="#2563EB", label=f"Retained (Mean: {ret_series.mean():.1f})", edgecolor="white", zorder=3)
        ax.hist(chn_series, bins=26, alpha=0.75, color="#DC2626", label=f"Churned (Mean: {chn_series.mean():.1f})", edgecolor="white", zorder=3)
        ax.axvline(ret_series.mean(), color="#1E40AF", linestyle="--", linewidth=1.8, label="Retained Mean", zorder=4)
        ax.axvline(chn_series.mean(), color="#991B1B", linestyle="--", linewidth=1.8, label="Churned Mean", zorder=4)
        ax.set_title(f"Distribution of {hist_col} by Churn Status", fontsize=13, fontweight="bold", pad=12)
        ax.set_xlabel(hist_col, fontsize=11, fontweight="semibold")
        ax.set_ylabel("Customer Frequency", fontsize=11, fontweight="semibold")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", linestyle="--", alpha=0.35, zorder=0)
        ax.legend(frameon=True, facecolor="white", edgecolor="#E2E8F0")
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Pyplot":
        plt.figure(figsize=(9, 4.6), dpi=130)
        plt.hist([ret_series, chn_series], bins=24, color=["#0F172A", "#EA580C"],
                 label=["Retained (No)", "Churned (Yes)"], edgecolor="#334155", alpha=0.85)
        plt.title(f"SCIENTIFIC FREQUENCY DISTRIBUTION: {hist_col.upper()}", fontsize=12.5, fontweight="bold", pad=12)
        plt.xlabel(hist_col, fontweight="bold")
        plt.ylabel("Frequency", fontweight="bold")
        plt.grid(True, linestyle=":", alpha=0.45, color="#64748B")
        plt.legend(frameon=True, facecolor="#F8FAFC", edgecolor="#94A3B8")
        plt.tight_layout()
        st.pyplot(plt.gcf())
        plt.close()

    elif active_lib == "Seaborn":
        fig, ax = plt.subplots(figsize=(9, 4.6), dpi=130)
        sns.histplot(
            data=filtered_df, x=hist_col, hue="Churn", bins=26, kde=True,
            palette={"No": "#16A34A", "Yes": "#E11D48"}, alpha=0.55, ax=ax
        )
        ax.set_title(f"Statistical Density & Distribution: {hist_col}", fontsize=13, fontweight="bold", pad=12)
        ax.set_xlabel(hist_col, fontsize=11, fontweight="semibold")
        ax.set_ylabel("Customer Count", fontsize=11, fontweight="semibold")
        sns.despine(top=True, right=True)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Bokeh":
        p = figure(
            title=f"Distribution of {hist_col} (Bokeh Interactive)",
            height=430,
            sizing_mode="stretch_width",
            tools="pan,wheel_zoom,box_zoom,reset,save"
        )
        bins = 24
        col_min = min(ret_series.min() if not ret_series.empty else 0, chn_series.min() if not chn_series.empty else 0)
        col_max = max(ret_series.max() if not ret_series.empty else 1, chn_series.max() if not chn_series.empty else 1)
        bin_edges = np.linspace(col_min, col_max, bins + 1)

        if not ret_series.empty:
            r_counts, _ = np.histogram(ret_series, bins=bin_edges)
            r_source = ColumnDataSource(pd.DataFrame({
                "top": r_counts,
                "left": bin_edges[:-1],
                "right": bin_edges[1:],
                "mid": (bin_edges[:-1] + bin_edges[1:]) / 2
            }))
            r_quad = p.quad(top="top", bottom=0, left="left", right="right", source=r_source,
                            fill_color="#2563EB", fill_alpha=0.6, line_color="white", legend_label="Retained (No)")
            p.add_tools(HoverTool(renderers=[r_quad], tooltips=[("Cohort", "Retained"), ("Range", "@left{0.0} to @right{0.0}"), ("Count", "@top")]))

        if not chn_series.empty:
            c_counts, _ = np.histogram(chn_series, bins=bin_edges)
            c_source = ColumnDataSource(pd.DataFrame({
                "top": c_counts,
                "left": bin_edges[:-1],
                "right": bin_edges[1:],
                "mid": (bin_edges[:-1] + bin_edges[1:]) / 2
            }))
            c_quad = p.quad(top="top", bottom=0, left="left", right="right", source=c_source,
                            fill_color="#DC2626", fill_alpha=0.6, line_color="white", legend_label="Churned (Yes)")
            p.add_tools(HoverTool(renderers=[c_quad], tooltips=[("Cohort", "Churned"), ("Range", "@left{0.0} to @right{0.0}"), ("Count", "@top")]))

        p.xaxis.axis_label = hist_col
        p.yaxis.axis_label = "Customer Count"
        p.legend.click_policy = "hide"
        render_bokeh_chart(p, height=440)

    st.markdown('</div>', unsafe_allow_html=True)

# =========================================================================
# GRAPH 3: CUSTOMER RELATIONSHIP SCATTER PLOT (ALL 4 LIBRARIES)
# =========================================================================

if "Scatter Plot" in graphs_to_display and not filtered_df.empty and len(num_cols) >= 2:
    st.markdown('<div class="chart-card">', unsafe_allow_html=True)
    st.subheader(f"3. Customer Relationship Scatter Plot — [{active_lib}]")
    st.caption("Multi-variable correlation mapping with churn cluster detection.")

    # Styled Chart Filter Control Bar
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">⚙️ Coordinate Mapping Controls</div>
    """, unsafe_allow_html=True)
    sc_col1, sc_col2 = st.columns(2)
    with sc_col1:
        x_axis = st.selectbox("↔️ X-Axis Attribute", num_cols, index=0, key="scatter_x_hub")
    with sc_col2:
        y_axis = st.selectbox("↕️ Y-Axis Attribute", num_cols, index=1 if len(num_cols) > 1 else 0, key="scatter_y_hub")
    st.markdown("</div>", unsafe_allow_html=True)

    sample_size = min(1500, len(filtered_df))
    scatter_df = filtered_df.sample(sample_size, random_state=42) if len(filtered_df) > 1500 else filtered_df

    if active_lib == "Matplotlib":
        fig, ax = plt.subplots(figsize=(9, 4.8), dpi=130)
        ret_pts = scatter_df[scatter_df["Churn"] == "No"]
        chn_pts = scatter_df[scatter_df["Churn"] == "Yes"]

        ax.scatter(ret_pts[x_axis], ret_pts[y_axis], c="#2563EB", alpha=0.55,
                   edgecolors="white", linewidth=0.6, s=48, label="Retained (No)", zorder=3)
        ax.scatter(chn_pts[x_axis], chn_pts[y_axis], c="#DC2626", alpha=0.75,
                   edgecolors="white", linewidth=0.6, s=54, label="Churned (Yes)", zorder=3)

        # Centroid markers
        if not ret_pts.empty:
            ax.scatter([ret_pts[x_axis].mean()], [ret_pts[y_axis].mean()], c="#1D4ED8",
                       marker="X", s=140, edgecolors="white", linewidth=1.5, label="Retained Centroid", zorder=5)
        if not chn_pts.empty:
            ax.scatter([chn_pts[x_axis].mean()], [chn_pts[y_axis].mean()], c="#B91C1C",
                       marker="X", s=140, edgecolors="white", linewidth=1.5, label="Churned Centroid", zorder=5)

        ax.set_title(f"{x_axis} vs {y_axis} by Churn Status", fontsize=13, fontweight="bold", pad=12)
        ax.set_xlabel(x_axis, fontsize=11, fontweight="semibold")
        ax.set_ylabel(y_axis, fontsize=11, fontweight="semibold")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, linestyle="--", alpha=0.3, zorder=0)
        ax.legend(frameon=True, facecolor="white", edgecolor="#E2E8F0")
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Pyplot":
        plt.figure(figsize=(9, 4.8), dpi=130)
        ret_pts = scatter_df[scatter_df["Churn"] == "No"]
        chn_pts = scatter_df[scatter_df["Churn"] == "Yes"]

        plt.scatter(ret_pts[x_axis], ret_pts[y_axis], c="#0F172A", alpha=0.6,
                    marker="o", s=45, label="Retained", edgecolors="#334155")
        plt.scatter(chn_pts[x_axis], chn_pts[y_axis], c="#EA580C", alpha=0.75,
                    marker="s", s=50, label="Churned", edgecolors="#9A3412")

        plt.title(f"SCIENTIFIC SCATTER ANALYSIS: {x_axis.upper()} vs {y_axis.upper()}", fontsize=12.5, fontweight="bold", pad=12)
        plt.xlabel(x_axis, fontweight="bold")
        plt.ylabel(y_axis, fontweight="bold")
        plt.grid(True, linestyle=":", alpha=0.45, color="#64748B")
        plt.legend(frameon=True, facecolor="#F8FAFC", edgecolor="#94A3B8")
        plt.tight_layout()
        st.pyplot(plt.gcf())
        plt.close()

    elif active_lib == "Seaborn":
        fig, ax = plt.subplots(figsize=(9, 4.8), dpi=130)
        sns.scatterplot(
            data=scatter_df, x=x_axis, y=y_axis, hue="Churn", style="Churn",
            markers={"No": "o", "Yes": "X"},
            palette={"No": "#16A34A", "Yes": "#E11D48"},
            alpha=0.65, s=60, ax=ax
        )
        ax.set_title(f"Seaborn Feature Scatter: {x_axis} vs {y_axis}", fontsize=13, fontweight="bold", pad=12)
        ax.set_xlabel(x_axis, fontsize=11, fontweight="semibold")
        ax.set_ylabel(y_axis, fontsize=11, fontweight="semibold")
        sns.despine(top=True, right=True)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Bokeh":
        p = figure(
            title=f"{x_axis} vs {y_axis} (Bokeh Interactive Scatter)",
            height=430,
            sizing_mode="stretch_width",
            tools="pan,wheel_zoom,box_zoom,reset,save"
        )
        b_scat = scatter_df[[x_axis, y_axis, "Churn", "Contract"]].copy()
        b_scat["color"] = b_scat["Churn"].map({"No": "#2563EB", "Yes": "#DC2626"})
        source = ColumnDataSource(b_scat)

        renderer = p.scatter(
            x=x_axis, y=y_axis, color="color", marker="circle",
            size=7, fill_alpha=0.65, line_color="white", source=source, legend_field="Churn"
        )
        hover = HoverTool(
            renderers=[renderer],
            tooltips=[
                ("Status", "@Churn"),
                ("Contract", "@Contract"),
                (x_axis, f"@{{{x_axis}}}{{0.0}}"),
                (y_axis, f"@{{{y_axis}}}{{0.0}}")
            ]
        )
        p.add_tools(hover)
        p.xaxis.axis_label = x_axis
        p.yaxis.axis_label = y_axis
        p.legend.click_policy = "hide"
        render_bokeh_chart(p, height=440)

    st.markdown('</div>', unsafe_allow_html=True)

# =========================================================================
# GRAPH 4: CUSTOMER TREND ANALYSIS (ALL 4 LIBRARIES)
# =========================================================================

if "Line Chart" in graphs_to_display and not filtered_df.empty:
    st.markdown('<div class="chart-card">', unsafe_allow_html=True)
    st.subheader(f"4. Customer Trend Analysis (Line Chart) — [{active_lib}]")
    st.caption("Tenure cohort progression for churn rates and customer billings.")

    # Styled Chart Filter Control Bar
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">⚙️ Cohort Trend Metric</div>
    """, unsafe_allow_html=True)
    trend_metric = st.selectbox(
        "Select Trend Metric",
        ["Churn Rate (%)", "Average Monthly Charges", "Average Total Charges", "Customer Count"],
        key="trend_metric_hub"
    )
    st.markdown("</div>", unsafe_allow_html=True)

    trend_source = filtered_df.copy()
    trend_source["tenure"] = pd.to_numeric(trend_source["tenure"], errors="coerce")
    trend_source = trend_source.dropna(subset=["tenure", "Churn"])

    if not trend_source.empty:
        trend_source["Tenure Group"] = pd.cut(
            trend_source["tenure"],
            bins=[-1, 12, 24, 48, 72],
            labels=["0-12 months", "13-24 months", "25-48 months", "49-72 months"],
            include_lowest=True
        )
        trend_source = trend_source.dropna(subset=["Tenure Group"])

        if trend_metric == "Churn Rate (%)":
            trend_data = (
                trend_source.groupby("Tenure Group", observed=False)
                .agg(
                    Customers=("Churn", "size"),
                    Churned=("Churn", lambda v: v.eq("Yes").sum())
                )
                .reset_index()
            )
            trend_data["Trend Value"] = (
                trend_data["Churned"] / trend_data["Customers"].replace(0, pd.NA) * 100
            ).fillna(0)
            y_label = "Churn Rate (%)"
            fmt_str = "{:.1f}%"
        elif trend_metric == "Average Monthly Charges":
            trend_data = (
                trend_source.groupby("Tenure Group", observed=False)
                .agg(**{"Trend Value": ("MonthlyCharges", "mean"), "Customers": ("Churn", "size")})
                .reset_index()
            )
            y_label = "Average Monthly Charges ($)"
            fmt_str = "${:.2f}"
        elif trend_metric == "Average Total Charges":
            trend_data = (
                trend_source.groupby("Tenure Group", observed=False)
                .agg(**{"Trend Value": ("TotalCharges", "mean"), "Customers": ("Churn", "size")})
                .reset_index()
            )
            y_label = "Average Total Charges ($)"
            fmt_str = "${:.2f}"
        else:
            trend_data = (
                trend_source.groupby("Tenure Group", observed=False)
                .agg(**{"Trend Value": ("Churn", "size")})
                .reset_index()
            )
            y_label = "Customer Count"
            fmt_str = "{:,.0f}"

        groups = trend_data["Tenure Group"].astype(str).tolist()
        vals = trend_data["Trend Value"].tolist()

        if active_lib == "Matplotlib":
            fig, ax = plt.subplots(figsize=(9.5, 4.6), dpi=130)
            ax.plot(groups, vals, color="#2563EB", marker="o", markersize=8.5,
                    linewidth=2.8, markerfacecolor="white", markeredgecolor="#2563EB",
                    markeredgewidth=2.2, zorder=3)
            ax.fill_between(range(len(groups)), vals, alpha=0.14, color="#2563EB", zorder=2)
            ax.set_title(f"{trend_metric} Across Customer Tenure Cohorts", fontsize=13, fontweight="bold", pad=12)
            ax.set_xlabel("Customer Tenure Group", fontsize=11, fontweight="semibold")
            ax.set_ylabel(y_label, fontsize=11, fontweight="semibold")
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            ax.grid(True, linestyle="--", alpha=0.32, zorder=0)
            for idx, (grp, v) in enumerate(zip(groups, vals)):
                ax.annotate(fmt_str.format(v), xy=(idx, v), xytext=(0, 9),
                            textcoords="offset points", ha="center", va="bottom",
                            fontsize=10, fontweight="bold", color="#1E293B")
            plt.tight_layout()
            st.pyplot(fig)
            plt.close(fig)

        elif active_lib == "Pyplot":
            plt.figure(figsize=(9.5, 4.6), dpi=130)
            plt.plot(groups, vals, color="#0F172A", marker="s", markersize=9,
                     linewidth=2.6, markerfacecolor="#EA580C", markeredgecolor="black", markeredgewidth=1.5)
            plt.title(f"TENURE COHORT TREND ANALYSIS: {trend_metric.upper()}", fontsize=12.5, fontweight="bold", pad=12)
            plt.xlabel("Tenure Cohort", fontweight="bold")
            plt.ylabel(y_label, fontweight="bold")
            plt.grid(True, linestyle=":", alpha=0.45, color="#64748B")
            for idx, v in enumerate(vals):
                plt.annotate(fmt_str.format(v), xy=(idx, v), xytext=(0, 9),
                             textcoords="offset points", ha="center", va="bottom",
                             fontsize=9.5, fontweight="bold",
                             bbox=dict(boxstyle="round,pad=0.25", facecolor="#F8FAFC", edgecolor="#94A3B8"))
            plt.tight_layout()
            st.pyplot(plt.gcf())
            plt.close()

        elif active_lib == "Seaborn":
            fig, ax = plt.subplots(figsize=(9.5, 4.6), dpi=130)
            sns.lineplot(
                data=trend_data, x="Tenure Group", y="Trend Value",
                marker="o", markersize=9, linewidth=2.8, color="#16A34A", ax=ax
            )
            ax.set_title(f"Seaborn Cohort Trend: {trend_metric}", fontsize=13, fontweight="bold", pad=12)
            ax.set_xlabel("Customer Tenure Group", fontsize=11, fontweight="semibold")
            ax.set_ylabel(y_label, fontsize=11, fontweight="semibold")
            sns.despine(top=True, right=True)
            for idx, v in enumerate(vals):
                ax.annotate(fmt_str.format(v), xy=(idx, v), xytext=(0, 8),
                            textcoords="offset points", ha="center", va="bottom",
                            fontsize=10, fontweight="semibold")
            plt.tight_layout()
            st.pyplot(fig)
            plt.close(fig)

        elif active_lib == "Bokeh":
            p = figure(
                x_range=groups,
                title=f"{trend_metric} Across Tenure Groups (Bokeh)",
                height=430,
                sizing_mode="stretch_width",
                tools="pan,wheel_zoom,box_zoom,reset,save"
            )
            b_trend = trend_data.copy()
            b_trend["val_formatted"] = [fmt_str.format(v) for v in vals]
            b_trend["group_str"] = groups
            source = ColumnDataSource(b_trend)

            p.line(x="group_str", y="Trend Value", line_width=3.2, color="#2563EB", source=source)
            renderer = p.scatter(x="group_str", y="Trend Value", size=10, fill_color="white",
                                 line_color="#2563EB", line_width=2.5, marker="circle", source=source)
            hover = HoverTool(
                renderers=[renderer],
                tooltips="""
                <div style="padding: 6px; font-family: sans-serif;">
                    <b>@group_str</b><br>
                    <span>Value: <b>@val_formatted</b></span>
                </div>
                """
            )
            p.add_tools(hover)
            p.xaxis.axis_label = "Customer Tenure Group"
            p.yaxis.axis_label = y_label
            render_bokeh_chart(p, height=440)

    st.markdown('</div>', unsafe_allow_html=True)

# =========================================================================
# GRAPH 5: CUSTOMER CHURN DISTRIBUTION (PIE / DONUT) (ALL 4 LIBRARIES)
# =========================================================================

if "Pie Chart" in graphs_to_display and not filtered_df.empty:
    st.markdown('<div class="chart-card">', unsafe_allow_html=True)
    st.subheader(f"5. Customer Churn Distribution (Pie / Donut Chart) — [{active_lib}]")
    st.caption("Visual share of churned vs retained customer accounts.")

    counts = filtered_df["Churn"].value_counts().reindex(["No", "Yes"], fill_value=0)
    ret_cnt = int(counts.get("No", 0))
    chn_cnt = int(counts.get("Yes", 0))
    tot_cnt = ret_cnt + chn_cnt
    ret_pct = (ret_cnt / tot_cnt * 100) if tot_cnt else 0
    chn_pct = (chn_cnt / tot_cnt * 100) if tot_cnt else 0

    if active_lib == "Matplotlib":
        fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=130)
        wedges, texts, autotexts = ax.pie(
            [ret_cnt, chn_cnt],
            labels=["Retained", "Churned"],
            autopct="%1.1f%%",
            startangle=90,
            colors=["#2563EB", "#DC2626"],
            wedgeprops=dict(width=0.42, edgecolor="white", linewidth=2.5),
            pctdistance=0.76,
            textprops=dict(fontsize=11, fontweight="semibold")
        )
        for at in autotexts:
            at.set_color("white")
            at.set_fontweight("bold")
        ax.text(0, 0.08, f"{tot_cnt:,}", ha="center", va="center", fontsize=15, fontweight="bold", color="#0F172A")
        ax.text(0, -0.12, "Total Cohort", ha="center", va="center", fontsize=9.5, color="#64748B", fontweight="semibold")
        ax.set_title("Customer Retention vs Churn Proportion (Donut Spec)", fontsize=13, fontweight="bold", pad=12)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Pyplot":
        plt.figure(figsize=(8.5, 4.8), dpi=130)
        wedges, texts, autotexts = plt.pie(
            [ret_cnt, chn_cnt],
            labels=["Retained (No)", "Churned (Yes)"],
            autopct="%1.1f%%",
            startangle=90,
            colors=["#0F172A", "#EA580C"],
            explode=(0, 0.09),
            shadow=True,
            textprops=dict(fontsize=11, fontweight="bold")
        )
        for at in autotexts:
            at.set_color("white")
            at.set_fontweight("bold")
        plt.title("CHURN COMPOSITION RATIO (PYPLOT SCIENTIFIC PIE)", fontsize=12.5, fontweight="bold", pad=12)
        plt.tight_layout()
        st.pyplot(plt.gcf())
        plt.close()

    elif active_lib == "Seaborn":
        fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=130)
        wedges, texts, autotexts = ax.pie(
            [ret_cnt, chn_cnt],
            labels=["Retained", "Churned"],
            autopct="%1.1f%%",
            startangle=90,
            colors=["#16A34A", "#E11D48"],
            wedgeprops=dict(width=0.42, edgecolor="white", linewidth=2.5),
            pctdistance=0.76,
            textprops=dict(fontsize=11, fontweight="semibold")
        )
        for at in autotexts:
            at.set_color("white")
            at.set_fontweight("bold")
        ax.text(0, 0, f"Churn\n{chn_pct:.1f}%", ha="center", va="center", fontsize=13, fontweight="bold", color="#1E293B")
        ax.set_title("Seaborn Churn Distribution Donut", fontsize=13, fontweight="bold", pad=12)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Bokeh":
        p = figure(
            height=430,
            title="Customer Churn Proportion (Bokeh Interactive Donut)",
            x_range=(-1.25, 1.25),
            y_range=(-1.25, 1.25),
            sizing_mode="stretch_width",
            tools="pan,wheel_zoom,reset,save"
        )
        angles = [ret_cnt / tot_cnt * 2 * pi, chn_cnt / tot_cnt * 2 * pi]
        start_angles = [0, angles[0]]
        end_angles = [angles[0], 2 * pi]

        b_pie = pd.DataFrame({
            "status": ["Retained (No)", "Churned (Yes)"],
            "count": [ret_cnt, chn_cnt],
            "pct": [f"{ret_pct:.1f}%", f"{chn_pct:.1f}%"],
            "start": start_angles,
            "end": end_angles,
            "color": ["#2563EB", "#DC2626"]
        })
        source = ColumnDataSource(b_pie)

        renderer = p.wedge(
            x=0, y=0, radius=0.88, start_angle="start", end_angle="end",
            color="color", line_color="white", line_width=2.5, source=source, legend_field="status"
        )
        p.scatter(x=[0], y=[0], size=140, marker="circle", color="white")

        hover = HoverTool(
            renderers=[renderer],
            tooltips="""
            <div style="padding: 6px; font-family: sans-serif;">
                <b style="color: @color; font-size: 13px;">@status</b><br>
                <span>Count: <b>@count{0,0}</b></span><br>
                <span>Share: <b>@pct</b></span>
            </div>
            """
        )
        p.add_tools(hover)
        p.axis.visible = False
        p.grid.visible = False
        p.legend.click_policy = "hide"
        render_bokeh_chart(p, height=440)

    st.markdown('</div>', unsafe_allow_html=True)

# =========================================================================
# GRAPH 6: BOX PLOT (ALL 4 LIBRARIES)
# =========================================================================

if "Box Plot" in graphs_to_display and not filtered_df.empty:
    st.markdown('<div class="chart-card">', unsafe_allow_html=True)
    st.subheader(f"6. Numerical Distribution Box Plot — [{active_lib}]")
    st.caption("Quartile dispersion, median values, and outlier detection across churn cohorts.")

    # Styled Chart Filter Control Bar
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">⚙️ Distribution Attribute Control</div>
    """, unsafe_allow_html=True)
    box_col = st.selectbox("Choose Numerical Attribute to Plot", num_cols, index=0 if "MonthlyCharges" in num_cols else 0, key="box_column_hub")
    st.markdown("</div>", unsafe_allow_html=True)

    ret_vals = filtered_df[filtered_df["Churn"] == "No"][box_col].dropna()
    chn_vals = filtered_df[filtered_df["Churn"] == "Yes"][box_col].dropna()

    if active_lib == "Matplotlib":
        fig, ax = plt.subplots(figsize=(9, 4.6), dpi=130)
        bp = ax.boxplot(
            [ret_vals, chn_vals],
            tick_labels=["Retained (No)", "Churned (Yes)"],
            patch_artist=True,
            showmeans=True,
            meanprops=dict(marker="D", markeredgecolor="#0F172A", markerfacecolor="#F59E0B", markersize=6),
            medianprops=dict(color="white", linewidth=2.2),
            whiskerprops=dict(color="#475569", linewidth=1.5),
            capprops=dict(color="#475569", linewidth=1.5),
            flierprops=dict(marker="o", color="#94A3B8", alpha=0.5, markersize=4)
        )
        colors = ["#2563EB", "#DC2626"]
        for patch, col in zip(bp["boxes"], colors):
            patch.set_facecolor(col)
            patch.set_alpha(0.75)
            patch.set_edgecolor("#1E293B")
            patch.set_linewidth(1.2)

        ax.annotate(f"Median: {ret_vals.median():.1f}", xy=(1, ret_vals.median()),
                    xytext=(28, 0), textcoords="offset points", ha="left", va="center",
                    fontsize=9.5, fontweight="bold", color="#1E40AF")
        ax.annotate(f"Median: {chn_vals.median():.1f}", xy=(2, chn_vals.median()),
                    xytext=(28, 0), textcoords="offset points", ha="left", va="center",
                    fontsize=9.5, fontweight="bold", color="#991B1B")

        ax.set_title(f"{box_col} Distribution by Churn Status", fontsize=13, fontweight="bold", pad=12)
        ax.set_ylabel(box_col, fontsize=11, fontweight="semibold")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", linestyle="--", alpha=0.32)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Pyplot":
        plt.figure(figsize=(9, 4.6), dpi=130)
        bp = plt.boxplot(
            [ret_vals, chn_vals],
            tick_labels=["Retained (No)", "Churned (Yes)"],
            notch=True,
            patch_artist=True,
            boxprops=dict(facecolor="#F1F5F9", edgecolor="#0F172A", linewidth=1.5),
            medianprops=dict(color="#EA580C", linewidth=2.2)
        )
        plt.title(f"SCIENTIFIC NOTCHED BOXPLOT: {box_col.upper()}", fontsize=12.5, fontweight="bold", pad=12)
        plt.ylabel(box_col, fontweight="bold")
        plt.grid(True, linestyle=":", alpha=0.45, color="#64748B")
        plt.tight_layout()
        st.pyplot(plt.gcf())
        plt.close()

    elif active_lib == "Seaborn":
        fig, ax = plt.subplots(figsize=(9, 4.6), dpi=130)
        sns.boxplot(
            data=filtered_df, x="Churn", y=box_col, hue="Churn",
            palette={"No": "#16A34A", "Yes": "#E11D48"},
            legend=False, width=0.45, ax=ax
        )
        sample_sub = filtered_df.sample(min(400, len(filtered_df)), random_state=42)
        sns.stripplot(
            data=sample_sub, x="Churn", y=box_col,
            color="#0F172A", alpha=0.25, jitter=0.2, size=3.5, ax=ax
        )
        ax.set_title(f"Seaborn Box & Strip Plot: {box_col}", fontsize=13, fontweight="bold", pad=12)
        ax.set_ylabel(box_col, fontsize=11, fontweight="semibold")
        ax.set_xlabel("Churn Status", fontsize=11, fontweight="semibold")
        sns.despine(top=True, right=True)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    elif active_lib == "Bokeh":
        p = figure(
            x_range=["Retained (No)", "Churned (Yes)"],
            title=f"{box_col} Box Plot (Bokeh Interactive)",
            height=430,
            sizing_mode="stretch_width",
            tools="pan,wheel_zoom,box_zoom,reset,save"
        )
        cats = ["Retained (No)", "Churned (Yes)"]
        q1_vals = [ret_vals.quantile(0.25), chn_vals.quantile(0.25)]
        q2_vals = [ret_vals.quantile(0.50), chn_vals.quantile(0.50)]
        q3_vals = [ret_vals.quantile(0.75), chn_vals.quantile(0.75)]
        iqr_vals = [q3_vals[0] - q1_vals[0], q3_vals[1] - q1_vals[1]]
        upper_vals = [min(ret_vals.max(), q3_vals[0] + 1.5 * iqr_vals[0]), min(chn_vals.max(), q3_vals[1] + 1.5 * iqr_vals[1])]
        lower_vals = [max(ret_vals.min(), q1_vals[0] - 1.5 * iqr_vals[0]), max(chn_vals.min(), q1_vals[1] - 1.5 * iqr_vals[1])]

        b_box = pd.DataFrame({
            "status": cats,
            "q1": q1_vals,
            "median": q2_vals,
            "q3": q3_vals,
            "upper": upper_vals,
            "lower": lower_vals,
            "color": ["#2563EB", "#DC2626"]
        })
        source = ColumnDataSource(b_box)

        renderer = p.vbar(x="status", width=0.45, bottom="q1", top="q3", fill_color="color",
                          line_color="#1E293B", fill_alpha=0.75, source=source)
        p.segment(x0="status", y0="lower", x1="status", y1="q1", line_color="#1E293B", line_width=1.8, source=source)
        p.segment(x0="status", y0="upper", x1="status", y1="q3", line_color="#1E293B", line_width=1.8, source=source)
        p.rect(x="status", y="lower", width=0.2, height=0.5, line_color="#1E293B", fill_color="#1E293B", source=source)
        p.rect(x="status", y="upper", width=0.2, height=0.5, line_color="#1E293B", fill_color="#1E293B", source=source)
        p.rect(x="status", y="median", width=0.45, height=1.0, line_color="white", fill_color="white", source=source)

        hover = HoverTool(
            renderers=[renderer],
            tooltips="""
            <div style="padding: 6px; font-family: sans-serif;">
                <b style="color: @color; font-size: 13px;">@status</b><br>
                <span>Median: <b>@median{0.0}</b></span><br>
                <span>Q1 (25%): <b>@q1{0.0}</b></span><br>
                <span>Q3 (75%): <b>@q3{0.0}</b></span><br>
                <span>Lower Whisker: <b>@lower{0.0}</b></span><br>
                <span>Upper Whisker: <b>@upper{0.0}</b></span>
            </div>
            """
        )
        p.add_tools(hover)
        p.xaxis.axis_label = "Churn Status"
        p.yaxis.axis_label = box_col
        render_bokeh_chart(p, height=440)

    st.markdown('</div>', unsafe_allow_html=True)

# =====================================================
# 13. AI-STYLE BUSINESS INSIGHTS
# =====================================================

st.divider()
st.header("🧠 AI Business Insights")
st.caption("Automatically generated analytical observations from the currently filtered dataset.")

if not filtered_df.empty:
    insights = []
    current_churn_rate = (filtered_df["Churn"].eq("Yes").mean() * 100)
    insights.append(f"The active cohort displays an aggregate churn rate of {current_churn_rate:.1f}%.")
    if "Contract" in filtered_df.columns:
        contract_summary = filtered_df.groupby("Contract", observed=False)["Churn"].apply(lambda x: x.eq("Yes").mean() * 100)
        if not contract_summary.empty:
            top_contract = contract_summary.idxmax()
            insights.append(f"**{top_contract}** accounts suffer the highest churn rate ({contract_summary.max():.1f}%) across contract tiers.")
    if "tenure" in filtered_df.columns:
        short_tenure_rate = filtered_df.loc[filtered_df["tenure"] <= 12, "Churn"].eq("Yes").mean() * 100
        if pd.notna(short_tenure_rate):
            insights.append(f"New accounts (tenure ≤ 12 months) register a **{short_tenure_rate:.1f}%** churn rate, indicating onboarding friction.")
    if "PaymentMethod" in filtered_df.columns:
        payment_summary = filtered_df.groupby("PaymentMethod", observed=False)["Churn"].apply(lambda x: x.eq("Yes").mean() * 100)
        if not payment_summary.empty:
            top_payment = payment_summary.idxmax()
            insights.append(f"**{top_payment}** demonstrates the highest payment-related churn ({payment_summary.max():.1f}%).")
    if model_ready:
        insights.append(f"The Random Forest model achieves an F1-score of **{model_metrics['f1'] * 100:.1f}%** on test data.")

    for insight in insights:
        st.markdown(f"- {insight}")

# =====================================================
# 14. PERSONALIZED RETENTION SUGGESTIONS
# =====================================================

st.divider()
st.header("🎯 Personalized Retention Suggestions")

if model_ready and not filtered_df.empty:
    st.markdown("""
    <div class="chart-filter-container">
        <div class="chart-filter-title">🎯 Customer Record Profile Selector</div>
    """, unsafe_allow_html=True)
    customer_choices = list(range(min(100, len(filtered_df))))
    selected_customer_number = st.selectbox(
        "Choose customer profile (from active filter cohort)",
        customer_choices,
        format_func=lambda x: f"Customer Record #{x + 1}",
        key="retention_customer_choice"
    )
    st.markdown("</div>", unsafe_allow_html=True)

    selected_customer = filtered_df.iloc[selected_customer_number]
    customer_features = selected_customer.drop(labels=["Churn"], errors="ignore").to_frame().T
    customer_probability = float(churn_model.predict_proba(customer_features)[0, 1])
    risk_label = "High" if customer_probability >= 0.60 else "Medium" if customer_probability >= 0.30 else "Low"

    p1, p2, p3 = st.columns(3)
    p1.metric("Predicted Churn Probability", f"{customer_probability * 100:.1f}%")
    p2.metric("Assigned Risk Level", risk_label)
    p3.metric("Actual Recorded Status", str(selected_customer.get("Churn", "Unknown")))

    suggestions = []
    contract_val = str(selected_customer.get("Contract", ""))
    tenure_val = float(selected_customer.get("tenure", 0) or 0)
    monthly_val = float(selected_customer.get("MonthlyCharges", 0) or 0)

    if contract_val == "Month-to-month":
        suggestions.append("Migrate customer from month-to-month to an annual or 2-year agreement with introductory discount incentives.")
    if tenure_val <= 12:
        suggestions.append("Initiate proactive customer success check-ins during the first 90 days to reinforce platform value.")
    if selected_customer.get("OnlineSecurity") == "No":
        suggestions.append("Bundle complementary cybersecurity & device protection features to increase product stickiness.")
    if selected_customer.get("TechSupport") == "No":
        suggestions.append("Assign priority 24/7 technical assistance to resolve recurring service issues rapidly.")
    if monthly_val >= filtered_df["MonthlyCharges"].median():
        suggestions.append("Review billing package and propose an optimized tier before price sensitivity triggers cancellation.")
    if customer_probability >= 0.60:
        suggestions.append("Deploy high-priority executive retention call with bespoke commercial concessions.")

    st.subheader("Recommended Retention Actions:")
    for sug in dict.fromkeys(suggestions):
        st.markdown(f"- {sug}")

# =====================================================
# 15. DATA QUALITY & DATASET MANAGEMENT
# =====================================================

st.divider()
st.header("🛡️ Data Quality & Export Management")

dq1, dq2, dq3 = st.columns(3)
dq1.metric("Original Dataset Rows", f"{len(raw_df):,}")
dq2.metric("Duplicate Rows", f"{raw_df.duplicated().sum():,}")
dq3.metric("Missing Values", f"{raw_df.isnull().sum().sum():,}")

with st.expander("Preview Customer Dataset"):
    st.dataframe(filtered_df.head(30), use_container_width=True)

csv_data = filtered_df.to_csv(index=False).encode("utf-8")
st.download_button(
    "⬇️ Download Filtered Customer Dataset (CSV)",
    data=csv_data,
    file_name="customer_churn_filtered.csv",
    mime="text/csv"
)

# =====================================================
# 16. FOOTER
# =====================================================

st.divider()
st.caption(
    "Customer Churn Intelligence Dash Board | "
    "Powered by Streamlit, Pandas, Matplotlib, Pyplot, Seaborn, Bokeh, and Scikit-learn."
)
